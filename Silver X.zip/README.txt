100% TOTALLY original not stolen at all

To Use ListBox:

Right Click Listbox and Press Refresh and the Right Click again and click Load to Textbox!